# Load ggplot2  
library(ggplot2)

# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View movies data frame 
View(movies)

# Plot critics_score and audience_score 
ggplot(data = movies, 
       mapping = aes(x = critics_score, 
                     y = audience_score,
                     color=genre)) +
  geom_point()
str(movies$mpaa_rating)
levels(movies$mpaa_rating)
#plot bar chart
#geom_line - plot line chart
#geom_boxplot - plot box plot
ggplot(data = movies, 
       mapping = aes(x = mpaa_rating)) + 
      geom_bar() + labs(y="Rating count",
          title="Count of mpaa rating")

ggplot(data = movies, 
       mapping = aes(x = mpaa_rating,fill=genre)) + 
  geom_bar() + labs(y="Rating count",
                    title="Count of mpaa rating")


ggplot(data = movies, 
       mapping = aes(x=runtime)) + 
  geom_histogram() + labs(x="Runtime of movies",
                    title="Distribution of runtime")
#assignment

library(datasets)
data(mtcars)
ggplot(data=mtcars,mapping=aes(x=cyl))+geom_bar()+labs(x="cyl",title="Distribution of cyl")