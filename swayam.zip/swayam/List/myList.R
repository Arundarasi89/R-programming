# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store the data frame 
captaincy <- read.csv("CaptaincyData.csv")

# View the stored data frame 
View(captaincy)
#create matrix from captaincy
subdata <- captaincy[1:3,c("played","won","lost")]
#convert sub data into matrix
matrixA <- as.matrix(subdata)
myVector <- c(1:5)
myList <- list(captaincy,matrixA,myVector)
names(myList) <- c("dataframe","matrix","vector")
print(myList)
myList$dataframe
#access element in matrix
myList[2]
myList[[2]][,3]

#combine two different lists
listSimple <- c("One","Two","Three")
merged.list <- c(myList,listSimple)
print(merged.list)


myVector2 <- c(1:5)
data <- c(1:15)
matrixB <- matrix(data,nrow=5,ncol=3)
print(matrixB)

library(datasets)
data(iris)
data(iris)
myList2 <- list(data(iris),matrixB)
names(myList2) <- c("dataframe","matrix")
print(myList2)

myList2$dataframe
myList2[2]
myList2[[2]][,3]


