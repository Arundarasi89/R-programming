# Clear R workspace
rm(list = ls() ) 

# Declare a sample vector
sampleVec <- c(1:6)
summary(sampleVec)
permutation <- function(a,b)
{
  factorial(a)/factorial(a-b)
}

permutation(5,2)

votingEligibility <- function()
{
  age <- as.integer(readline("Enter your age:"))
  if(age<18)
  {
    print("You cant cast your vote")
  }
  else{
    print("You can cast your vote")
  }
}
votingEligibility()

sum_between_two <- function(n1,n2)
{
  result <- 0
  for(i in n1:n2)
  {
    result <- result+i
  }
  return (result)
}
sum_between_two(2,6)
#assignment

combine <- function(n1,n2)
{
  r <- n1+n2
  return (r)
}
combine(2,3)
