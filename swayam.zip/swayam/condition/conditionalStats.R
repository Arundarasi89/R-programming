# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View movies data frame 
View(movies)

# Scores by India and Australia in three ODIs
inScore <- c(320, 260, 240)
ausScore <- c(280, 268, 240)
if(inScore[1]>ausScore[1])
{
  print("India won the first ODI!")
}
if(inScore[2]>ausScore[2])
{
  print("India won the second ODI!")
}else
{
  print("Australia won the second ODI!")
}

ifelse(inScore[2]>ausScore[2],"India won the second ODI!","Australia won the second ODI!")
#first statement -> true
#second statemnet -> false

#not correct
if(inScore[3]>ausScore[3])
{
  print("India won the third ODI!")
}else
{
  print("Australia won the third ODI!")
}

# correct
if(inScore[3]>ausScore[3])
{
  print("India won the third ODI!")
}else if(inScore[3]==ausScore[3])
{
  print("Third ODI was a tie")
}else
{
  print("Australia won the third ODI!")
}
movies$dev <- ifelse(movies$audience_score>movies$critics_score,1,0)
View(movies)
sum(ifelse(movies$audience_score>movies$critics_score,1,0))

#assignment
library(datasets)
data(iris)
sum(ifelse(iris$Sepal.Length>iris$Petal.Length,1,0))



