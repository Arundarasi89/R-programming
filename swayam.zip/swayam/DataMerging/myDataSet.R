library(XML)
#Clear R workspace
rm(list = ls()) 

# Declare a variable to store the data frame
captaincyOne = read.csv("CaptaincyData.csv")

# View the stored data frame 
View(captaincyOne)
summary(captaincyOne)
class(captaincyOne)
typeof(captaincyOne)
help(typeOf)
head(captaincyOne,2)
tail(captaincyOne,2)
str(captaincyOne)

#merge two datasets
captaincyTwo <- read.csv("CaptaincyData2.csv")
View(captaincyTwo)
captaincyOne <- merge(captaincyOne,captaincyTwo,by="names")
View(captaincyOne)
#Importing data in different formats
#install xml package

xmldata <- xmlToDataFrame("CaptaincyData.xml")
View(xmldata)
txtdata <- read.table("CaptaincyData.txt")
View(txtdata)



