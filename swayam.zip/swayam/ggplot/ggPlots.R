# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")
x <- seq(-pi,pi,0.1)
y <- sin(x)
plot(x,y)
#type of plot and color of plot
plot(x,y,
     main="Plotting a sine curve",
     ylab="sin(x)",
     type="l",
     col="blue")
#two graphs in one plot
plot(x,sin(x),
     main="Two graphs in one plot",
     ylab="",
     type="l",
     col="blue")
lines(x,cos(x),
      col="red")
legend("topleft",
       c("sin(x)","cos(x)"),
       fill=c("blue","red"))

library(ggplot2)
View(movies)
ggplot(data=movies,
       mapping=aes(x=critics_score,
                   y=audience_score)) + 
  geom_point()

#geom points are used to draw points defined by x and y coordinates
?ggsave

ggsave("scatter_plot.png")

library(datasets)
data(mtcars)
summary(mtcars)
str(mtcars)

plot(mtcars$mpg,mtcars$wt,
     main="Plotting mpg vs wt",xlab="wt",
     ylab="mpg",
     type="l",
     col="blue")


