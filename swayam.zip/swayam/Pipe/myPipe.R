# Load libraries   
library(ggplot2)
library(dplyr)

# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View movies data frame 
View(movies)
summarise(movies,mean(imdb_rating))

#we dont useful for finding mean and median only
#only useful when using group by

groupMovies <- group_by(movies,genre)

summarise(groupMovies,mean(imdb_rating))
#mean of filtered and grouped movies
dramaMov <- filter(movies,genre=="Drama")
gr_dramaMov <- group_by(dramaMov,mpaa_rating)
summarise(gr_dramaMov,mean(imdb_rating))

#alternative to above code
movies %>% filter(genre=="Drama")%>%group_by(mpaa_rating) %>% group_by(mpaa_rating) %>% summarise(mean(imdb_rating))
#easier to write - no need to repeat name of dataframe but write only once


movies %>% mutate(diff=audience_score - critics_score)%>% ggplot(mapping = aes(x=genre,y=diff))+
  geom_boxplot()

#analysis done on these two variables
movies %>% group_by(genre,mpaa_rating) %>% summarise(num=n())
#n() - computes number of time the event with specific condition has happened

library(datasets)
data(iris)
iris %>% group_by(Species) %>% summarise(mean(Sepal.Length),mean(Sepal.Width))



