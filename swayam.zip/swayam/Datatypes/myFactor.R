
# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store the data frame 
captaincy <- read.csv("CaptaincyData.csv")

# View the stored data frame 
View(captaincy)

testData <- TRUE
class(testData)
testData <- "TRUE"
class(testData)

testData <- 12
class(testData)

testData <- 12.3
class(testData)

testData <- as.integer(12)
class(testData)

testData <- 12L
class(testData)

str(captaincy)
#factors are data objects - categorize data as levels

print(captaincy$names)
#change type from factor to character
captaincy$names <- as.character(captaincy$names)
str(captaincy)
captaincy$format <- factor(captaincy$formats)
str(captaincy)
levels(captaincy$format)
#convert levels to words
levels(captaincy$formats) <- c("One","Two","Three")
print(captaincy$format)

library(datasets)

data(iris)
summary(iris)
str(iris)
levels(iris$Species)




