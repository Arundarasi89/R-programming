# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View movies data frame
View(movies)
#install.packages("dplyr")
#library(dplyr)
moviesComedy <- filter(movies,genre=="Comedy")

View(moviesComedy)
moviesComDr <- filter(movies,genre=="Comedy" | genre=="Drama")
#user logical OR operator
View(moviesComDr)


moviesComDrP <- filter(movies,genre %in% c("Comedy","Drama"))
#user logical OR operator
View(moviesComDrP)

moviesComIn <- filter(movies,genre=="Comedy"&imdb_rating>=7.5)
View(moviesComIn)

#sort in asscending order of imdb rating
moviesImA <- arrange(movies,imdb_rating)
View(moviesImA)

#sort in descending order of imdb rating
moviesImD <- arrange(movies,desc(imdb_rating))
View(moviesImD)
#sort by both genre and imdb rating
moviesImB <- arrange(movies,genre,imdb_rating)
View(moviesImB)

library(datasets)
data(mtcars)
str(mtcars)
mtcarsA <- filter(mtcars,hp>=100&cyl==3)
View(mtcarsA)

mtcarsB<- arrange(mtcars,mpg)



