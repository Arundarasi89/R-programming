# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View the stored data frame 
View(movies)

# View the dimension of the data frame 
dim(movies)
hist(movies$runtime)
hist(movies$runtime,main="Distribution of movies' length",xlab="Runtime of movies",xlim=c(0,300),col="blue",breaks=4)
genreCount <- table(movies$genre)
View(genreCount)
pie(genreCount)
pie(genreCount,main="Proportion of movies' genre",border="blue",col="orange")

hist(movies$imdb_num_votes)
hist(movies$imdb_num_votes,main="Distribution of imdb_num_votes",xlab="imdb_num_votes of movies",xlim=c(0,1000000),col="blue",breaks=4)
pie(mpaa_rating)
pie(mpaa_rating,main="Proportion of mpaa_rating",border="blue")



