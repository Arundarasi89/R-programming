# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View the stored data frame 
View(movies)

# View the dimension of the data frame 
dim(movies)
#first 20 observations
moviesSub <- movies[1:20,]
barplot(moviesSub$imdb_rating,ylab="IMDB rating",xlab="Movies",col="blue",ylim=c(0,10),main="Movies' IMDB rating",names.arg=moviesSub$title,las=2)
#make names perpendicular to bars

#scatter plot
plot(x=movies$imdb_rating,y=movies$audience_score,main="IMDB rating vs audience score",xlab="IMDB rating",ylab="Audience score",xlim=c(0,10),ylim=c(0,100),col="blue")
cor(movies$imdb_rating,movies$audience_score)

#assignment
moviesData <- movies[1:10,]
barplot(moviesData$critics_score,ylab="critics_score",xlab="Movies",col="blue",ylim=c(0,100),main="Movies' critic score",,names.arg=moviesData$title,las=2)

plot(x=movies$imdb_rating,y=movies$imdb_num_votes,main="IMDB rating vs IMDB num votes",xlab="IMDB rating",ylab="IMDB num votes",xlim=c(0,10),ylim=c(0,100),col="blue")

