# Load dplyr package 
library(dplyr)

# Clear R workspace
rm(list = ls() ) 

# Declare a variable to read and store moviesData  
movies <- read.csv("moviesData.csv")

# View movies 
View(movies)

# Filter the movies having genre as Comedy
moviesComedy <- filter(movies,
                       genre == "Comedy")
View(moviesComedy)

# Filter the movies having genre as either Comedy or Drama
moviesComDr <- filter(movies,
                      genre == "Comedy" | genre == "Drama")
View(moviesComDr)

# Filter the movies by using match operator
moviesComDrP <- filter(movies,
                       genre %in% c("Comedy", "Drama")) 
View(moviesComDrP)

# Filter the movies having genre as Comedy and imdb_rating >= 7.5
moviesComIm <- filter(movies,
                       genre == "Comedy" & imdb_rating >= 7.5)
View(moviesComIm)

# Arrange the movies in ascending order of imdb_rating
moviesImA <- arrange(movies, imdb_rating) 
View(moviesImA)

# Arrange the movies in descending order of imdb_rating
moviesImD <- arrange(movies, desc(imdb_rating)) 
View(moviesImD)

# Arrange the movies both by genre and imdb_rating
moviesGeIm <- arrange(movies, genre, imdb_rating)
View(moviesGeIm)

moviesTGI <- select(movies,title,genre,imdb_rating)
View(moviesTGI)

moviesTHT <- select(movies,title,starts_with("thr"))
View(moviesTHT)


moviesR <- rename(movies,rel_year="thtr_rel_year")
View(moviesR)

moviesless <- select(movies,title:audience_score)
moviesMu <- mutate(moviesless,CriAud=critics_score - audience_score)
View(moviesMu)

library(datasets)
data(airquality)

dataOWT <- select(airquality,Ozone,Wind,Temp)
View(dataOWT)

data(mtcars)
dataMC <- rename(mtcars,mpg="MilesPerGallon",cyl="Cylinder")
View(dataMC)

